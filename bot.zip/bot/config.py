MODEL = "gemini-flash-1.5"
MAX_TOKENS = 30
TEMPERATURE = 0.7
#TIMEOUT=10
#MAX_RETRIES=3

# gemini-flash-1.5-8b    gemini-flash-1.5    gpt-4o      gpt-4o-mini         deepseek-chat    deepseek-r1

PROMPT = (
    "Придумай {n} username для Telegram по контексту: '{context}'.\n"
    "Прибавляй на конце bot или _bot только если в контексте прямо указано, что это username для бота."
    "Используй только латинские буквы, цифры и нижнее подчёркивание."
    "Длина username должна быть от 5 до 32 символов. Выведи их в виде списка через запятую."
)


### логирование ###
import logging

# Основные настройки
LOG_LEVEL = logging.DEBUG  # Можно менять на INFO, WARNING, ERROR
LOG_FILE = "bot.log"  # Оставьте пустым "", если хотите логи только в консоль
LOG_FORMAT = "%(asctime)s - %(levelname)s - %(message)s"

# Функция для настройки логирования
def setup_logging():
    logging.basicConfig(
        level=LOG_LEVEL,
        format=LOG_FORMAT,
        filename=LOG_FILE if LOG_FILE else None,
        filemode="w" if LOG_FILE else None
    )

##################
